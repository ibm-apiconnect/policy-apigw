console.error("RATELIMIT-GWP.JS got gold");
